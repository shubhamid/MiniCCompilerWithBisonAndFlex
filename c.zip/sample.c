#include<stdio.h>
#include<conio.h>
#include"y.tab.h"
#define a 23
/*void disp()
{
	printf();
}*/
void main()
{
switch(a)
{
case 1: printf("as"); for(i=0;i<3;i++); break;
case 2: printf("sa"); break;
default: printf("as");
}
printf("as");
scanf("asd");
void print(char ch , int b, int f)
{
printf("as");
}
int a=0;
do
{
	printf("do");
}while(a==9);
//Sample testing file
/*
printf();*/
struct books
{
/*abc*/
//printf(vc);
char b;
int a;
//int a;
//a++;
};
mail();
//#include<iostream.h>
a=mail();
if(a>3)
{
	if(bb>=vv)	
	printf("asd %d",c,d);
}
if(a==2)
printf("asd");
int bb=00, a=0, c = 0, d = 0, f ,g ,h = 0;
float b;
while(as)
{
printf("asd");
}
for(i=0;i<3;i++)
{
printf("a");
for(j=0;j<2;j++)
{
bn++;//abc
bn=bn+3;
}
int main1()
{
}
}
}
void print()
{
printf("2");
}

